import hashlib  
import json  
from time import time  
  
# creating the Block_chain class  
class Block_chain(object):  
    def __init__(self):  
        self.chain = []  
        self.pendingTransactions = []  
        self.newBlock(previousHash = "The first Transaction", the_proof = 100)
    def newBlock(self, the_proof, previousHash = None):  
        the_block = {  
            'index': len(self.chain) + 1,  
            'timestamp': time(),  
            'transactions': self.pendingTransactions,  
            'proof': the_proof,  
            'previous_hash': previousHash or self.hash(self.chain[-1]),  
        }  
        self.pendingTransactions = []  
        self.chain.append(the_block)  
  
        return the_block
    
block_chain = Block_chain()  
print("Genesis block: ", block_chain.chain)  
